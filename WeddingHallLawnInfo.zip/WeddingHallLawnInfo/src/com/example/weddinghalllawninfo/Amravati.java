package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Amravati extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.amravati);
		
		Button b1 = (Button) findViewById(R.id.button1_desh);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Amravati.this,Deshmukkh.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b2 = (Button) findViewById(R.id.button2_sans);

		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Amravati.this, Sanskar.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b3 = (Button) findViewById(R.id.button3_tulja);

		b3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Amravati.this,Tulja.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b4 = (Button) findViewById(R.id.button4_vinay);

		b4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Amravati.this, Vinay.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
	

	}
}
