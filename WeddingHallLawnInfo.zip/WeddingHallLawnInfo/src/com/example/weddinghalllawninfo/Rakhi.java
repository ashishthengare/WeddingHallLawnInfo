package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Rakhi extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.rakhi);
		
		Button b1 = (Button) findViewById(R.id.button1_desh);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Rakhi.this,deshmukhcel.class);
				startActivity(i);
				setContentView(R.layout.rakhi);
			}
	});

	}


}
