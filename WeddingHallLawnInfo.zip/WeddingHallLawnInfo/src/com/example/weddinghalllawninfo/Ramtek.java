
package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Ramtek extends Activity{

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ramtekk);
		
		Button b1 = (Button) findViewById(R.id.button1_bus);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Ramtek.this, Busstop.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b2 = (Button) findViewById(R.id.button2_shital);

		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Ramtek.this, Shitalwadi.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b3 = (Button) findViewById(R.id.button3_amba);

		b3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Ramtek.this, Ambedkar.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b4 = (Button) findViewById(R.id.button4_rakhii);

		b4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Ramtek.this, Rakhi.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
	
}
}
