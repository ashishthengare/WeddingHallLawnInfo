package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Nagpur extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.nagpur);

		Button b1 = (Button) findViewById(R.id.button1);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, Dhantoli.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b2 = (Button) findViewById(R.id.button2);

		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, Dharampeth.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b3 = (Button) findViewById(R.id.button3);

		b3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, Hudkeshwar.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b4 = (Button) findViewById(R.id.button4);

		b4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, Itwari.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		
		Button b5 = (Button) findViewById(R.id.button5_manewada);

		b5.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, manewada.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b6 = (Button) findViewById(R.id.button6);

		b6.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, nandanvan.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b7 = (Button) findViewById(R.id.button7);

		b7.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, sadar.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b8 = (Button) findViewById(R.id.button8);

		b8.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, civil.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b9 = (Button) findViewById(R.id.button9);

		b9.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, ravi.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b10 = (Button) findViewById(R.id.button10);

		b10.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, laxmi.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});
		Button b11 = (Button) findViewById(R.id.button11_ambazari);

		b11.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Nagpur.this, ambazari.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
		});


	}
}
