package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Chandrapur extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chandrapur);
		
		Button b1 = (Button) findViewById(R.id.button1_kanyaka);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Chandrapur.this, Kanyaka.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b2 = (Button) findViewById(R.id.button2_gujrati);

		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Chandrapur.this, Gujrati.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b3 = (Button) findViewById(R.id.button3_mahesh);

		b3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Chandrapur.this, Mahesh.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
		Button b4 = (Button) findViewById(R.id.button4_yashodhara);

		b4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Chandrapur.this, Yashodhara.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
	
		Button b5 = (Button) findViewById(R.id.button5_prince);

		b5.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Chandrapur.this,Prince.class);
				startActivity(i);
				setContentView(R.layout.next);
			}
	});
	

	}

}
