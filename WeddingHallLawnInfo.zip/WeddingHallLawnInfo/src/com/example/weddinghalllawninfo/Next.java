package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class Next extends Activity {
	// protected static final String context = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.next);

		ImageButton b1 = (ImageButton) findViewById(R.id.imageButton1_nagpur);
		ImageButton b2 = (ImageButton) findViewById(R.id.imageButton2_ramtek);
		ImageButton b3 = (ImageButton) findViewById(R.id.imageButton3_chandrapur);
		ImageButton b4 = (ImageButton) findViewById(R.id.imageButton4_amravati);

		b1.setOnClickListener(new OnClickListener() {

			// @Override

			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent j = new Intent(Next.this, Nagpur.class);
				// setContentView(R.layout.nagpur);
				startActivity(j);
				finish();
			}
		});
		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent j = new Intent(Next.this, Ramtek.class);
				// setContentView(R.layout.ramtek);
				startActivity(j);

			}
		});
		b3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent j = new Intent(Next.this, Chandrapur.class);
				// setContentView(R.layout.chandrapur);
				startActivity(j);

			}
		});
		b4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent j = new Intent(Next.this, Amravati.class);
				// setContentView(R.layout.amravati);
				startActivity(j);
                finish();
			}
		});

	}
}