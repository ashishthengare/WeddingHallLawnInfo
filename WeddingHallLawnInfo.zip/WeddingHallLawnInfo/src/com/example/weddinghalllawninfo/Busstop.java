package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Busstop extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.busstop);

		Button b1 = (Button) findViewById(R.id.button1_khadatkar);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Busstop.this, Khadatkar.class);
				startActivity(i);
				setContentView(R.layout.busstop);
			
			}
		});
		Button b2 = (Button) findViewById(R.id.button2_shantiman);

		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent i = new Intent(Busstop.this, Shanti.class);
				startActivity(i);
				setContentView(R.layout.busstop);
			}
		});

	}

}
