package com.example.weddinghalllawninfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Shitalwadi extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.shitalwadi);

		Button b1 = (Button) findViewById(R.id.button1_swastikl);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
			
				Intent i = new Intent(Shitalwadi.this, Swastik.class);
				startActivity(i);
				setContentView(R.layout.shitalwadi);
			}
		});

	}

}
